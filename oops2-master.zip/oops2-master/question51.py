class animal:
    def animal_attribute(self):


        print(' inheriting Animal and access the base class method.')


class tiger(animal):
    pass


s1 = tiger()
s1.animal_attribute()
